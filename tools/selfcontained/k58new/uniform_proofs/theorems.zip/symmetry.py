from itertools import combinations
from collections import Counter
from functools import lru_cache
from pathlib import Path
from data import template,catalogue
A = template()
def isos(left,right,palette):
 n=len(left)
 counts=lambda T,i,c:sum(T[i][j]==c for j in range(n)if i!=j)
 candidates=[[j for j in range(n)if all(counts(left,i,c)==counts(right,j,palette[c])for c in range(4))]for i in range(n)]
 assignment={}
 def branch():
    if len(assignment)==n:
      yield tuple(assignment[i]for i in range(n));return
    options=[]
    for i in range(n):
      if i in assignment:continue
      opts=[j for j in candidates[i]if j not in assignment.values() and all(palette[left[i][k]]==right[j][v] for k,v in assignment.items())]
      options.append((len(opts),i,opts))
    _,i,opts=min(options)
    for j in opts:
      assignment[i]=j;yield from branch();del assignment[i]
 return list(branch())

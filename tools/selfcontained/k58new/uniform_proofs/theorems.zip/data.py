"""Exact T-template and root-arm catalogue used by the finite enumeration."""
from itertools import combinations, permutations
from pathlib import Path

HERE = Path(__file__).resolve().parent
COLORS = range(4)
ORDINARY = (1, 2, 3)
SIX = (6, 8, 10, 12, 16, 17)


def template():
    header, *rows = (HERE / 'T.col').read_text().splitlines()
    assert header == '15 4'
    m = [list(map(int, row.split())) for row in rows]
    assert len(m) == 15 and all(len(row) == 15 for row in m)
    assert all(1 <= m[i][j] == m[j][i] <= 3 for i, j in combinations(range(15), 2))
    return m


def omitting_words(m):
    # With five zeros, a missing ordinary color forces the other two parts
    # to be disjoint independent five-sets.
    independent = {}
    for c in ORDINARY:
        independent[c] = [sum(1 << a for a in s) for s in combinations(range(15), 5)
                          if all(m[a][b] != c for a, b in combinations(s, 2))]
    words = []
    for missing in ORDINARY:
        f, g = [c for c in ORDINARY if c != missing]
        for left in independent[f]:
            for right in independent[g]:
                if not left & right:
                    w = [(1 << 15) - 1 - left - right, 0, 0, 0]
                    w[f], w[g] = left, right
                    words.append(tuple(w))
    assert len(set(words)) == len(words) == 18
    return words


def palette_maps(m, words, return_points=False):
    """Exhibit one verified point permutation for every ordinary color permutation."""
    result = {}
    for perm in permutations(ORDINARY):
        palette = (0,) + perm
        options = [[j for j in range(15) if all(m[i].count(c) == m[j].count(palette[c])
                                                   for c in ORDINARY)] for i in range(15)]
        image = {}

        def extend():
            if len(image) == 15:
                return dict(image)
            choices = []
            for i in range(15):
                if i in image:
                    continue
                candidates = [j for j in options[i] if j not in image.values() and
                              all(m[j][y] == palette[m[i][x]] for x, y in image.items())]
                choices.append((i, candidates))
            i, candidates = min(choices, key=lambda item: len(item[1]))
            for j in candidates:
                image[i] = j
                answer = extend()
                if answer is not None:
                    return answer
                del image[i]
            return None

        sigma = extend()
        assert sigma is not None and sorted(sigma.values()) == list(range(15))
        assert all(m[sigma[i]][sigma[j]] == palette[m[i][j]] for i, j in combinations(range(15), 2))
        lookup = []
        for old in words:
            new = [0] * 4
            for c in COLORS:
                new[palette[c]] = sum(1 << sigma[a] for a in range(15) if old[c] & (1 << a))
            lookup.append(words.index(tuple(new)))
        result[perm] = tuple(sigma[i] for i in range(15)) if return_points else lookup
    return result


def graph_edges(code):
    assert ord(code[0]) - 63 == 14
    bits = [(ord(ch) - 63) >> b & 1 for ch in code[1:] for b in reversed(range(6))]
    pairs = [(i, j) for j in range(14) for i in range(j)]
    return {e for e, bit in zip(pairs, bits) if bit}


def catalogue():
    matrices = []
    for line in (HERE / 'armtypes14.txt').read_text().splitlines():
        if line.startswith('#'):
            continue
        idx, e0, e1, e2, code0, code1 = line.split()
        assert int(idx) == len(matrices)
        z, first = graph_edges(code0), graph_edges(code1)
        assert not z & first and (len(z), len(first), 91-len(z)-len(first)) == tuple(map(int, (e0, e1, e2)))
        m = {(i, j): 0 if (i, j) in z else 1 if (i, j) in first else 2 for i,j in combinations(range(14), 2)}
        assert all(not m[i,j] == m[i,k] == m[j,k] for i,j,k in combinations(range(14), 3))
        matrices.append(''.join(str(m[e]) for e in combinations(range(14), 2)))
    assert len(matrices) == 332
    return matrices


def candidate_multisets(words, k):
    """Necessary conditions on the k selected vertices in root arm 1."""
    allowed = [[sum(1 << f for f in (0, 2, 3) if not (x[f] & y[f])) for y in words] for x in words]
    out = []

    def grow(chosen, counts):
        if len(chosen) == k:
            out.append(tuple(chosen))
            return
        for j in range(chosen[-1] if chosen else 0, len(words)):
            palette = [allowed[i][j] for i in chosen]
            if not all(palette):
                continue
            if any(palette[a].bit_count() == 1 and palette[a] == palette[b] == allowed[chosen[a]][chosen[b]]
                   for a,b in combinations(range(len(chosen)), 2)):
                continue
            new = [n + ((words[j][0] >> a) & 1) for a, n in enumerate(counts)]
            if max(new) <= 5:
                grow(chosen + [j], new)

    grow([], [0] * 15)
    return out

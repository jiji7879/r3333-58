"""Integer replay of separating inequalities for the minimum number of zero sets."""
from itertools import combinations_with_replacement, product
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent

def spectra():
    for k in range(9,12):
        for sizes in combinations_with_replacement(range(1,7),k):
            if sum(sizes)==42 and sum(s>=5 for s in sizes)<=3:
                yield tuple(sizes.count(s) for s in range(1,7))

def system(n):
    # n[j] is the number of different supports of multiplicity j+1.
    patterns=[t for t in product(*(range(s+1) for s in n))
              if sum((j+1)*v for j,v in enumerate(t))==14 and t[4]+t[5]<=2
              and (t[5]==0 or t[4]+t[5]==1)]
    eq=[[1]*len(patterns)]+[[t[j] for t in patterns] for j in range(6)]
    rhs=[15]+[5*s for s in n]
    # All rows of G are written with the same sign, G x <= h.
    G=eq+[[-v for v in r] for r in eq]
    h=rhs+[-v for v in rhs]
    G.append([int(t[4]==2) for t in patterns])
    h.append((n[4]*n[4])//4)
    for i,j in combinations_with_replacement(range(6),2):
        pairs=n[i]*n[j] if i!=j else n[i]*(n[i]-1)//2
        if pairs:
            G.append([t[i]*t[j] if i!=j else t[i]*(t[i]-1)//2 for t in patterns])
            h.append(pairs*max(0,min(4,11-(i+1)-(j+1))))
    return G,h

def verify():
    records=json.loads((HERE/'multiplicity-certs.json').read_text())
    assert {tuple(r['counts']) for r in records}==set(spectra()) and len(records)==len(set(spectra()))
    for r in records:
        G,h=system(r['counts']);y=r['weights']
        assert len(y)==len(G) and all(type(v)==int and v>=0 for v in y)
        assert sum(a*b for a,b in zip(y,h))<0
        assert all(sum(a*b for a,b in zip(y,col))>=0 for col in zip(*G))
    print(f'Integer certificates exclude all {len(records)} multiplicity spectra with 9, 10 or 11 zero sets.',flush=True)

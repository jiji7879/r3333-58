#include <array>
#include <vector>
#include <fstream>
#include <iostream>
#include <cstdint>
#include <algorithm>
using namespace std;
using Bits=uint64_t;const int MAX=400;
struct Choice{int s,t;array<Bits,4> yes,no;};
using Set=array<Bits,MAX>;vector<Choice> opts;vector<Set> compat;Set dom[40],revdom[40];int L,R;long long nodes=0;long long limit;int sol[15];
using Counts=array<int,40>;
int nb; array<array<Bits,16>,40> permits; vector<Counts> rightDesign;
bool search(Set allowed,Counts left, Counts used, Bits designs,int depth){
 ++nodes;if(depth==15)return true;if(limit>0&&nodes>limit)return false;
 int source=-1,small=99999;
 for(int i=0;i<L;i++)if(left[i]){
  int n=0;for(int b=0;b<nb;b++)n+=__builtin_popcountll(allowed[b]&dom[i][b]);
  if(!n)return false;if(n<small){small=n;source=i;}
 }
 for(int q=0;q<R;q++)if(designs&permits[q][used[q]+1]){
  bool ok=false;for(int b=0;b<nb;b++)if(allowed[b]&revdom[q][b]){ok=true;break;}
  if(!ok){designs&=~permits[q][used[q]+1];if(!designs)return false;}
 }
 for(int b=0;b<nb;b++)for(Bits rem=allowed[b]&dom[source][b];rem;rem&=rem-1){
  int id=64*b+__builtin_ctzll(rem),t=opts[id].t;Bits ds=designs&permits[t][used[t]+1];if(!ds)continue;
  Set nx;for(int k=0;k<nb;k++)nx[k]=allowed[k]&compat[id][k];
  --left[source];++used[t];
  if(!left[source])for(int k=0;k<nb;k++)nx[k]&=~dom[source][k];
  else {for(int k=0;k<b;k++)nx[k]&=~dom[source][k];nx[b]&=~(dom[source][b]&((Bits(1)<<(id%64))-1));}
  for(int q=0;q<R;q++)if(!(ds&permits[q][used[q]+1]))for(int k=0;k<nb;k++)nx[k]&=~revdom[q][k];
  sol[depth]=id;if(search(nx,left,used,ds,depth+1))return true;
  ++left[source];--used[t];if(limit>0&&nodes>limit)return false;
 }
 return false;
}
int main(int argc,char**argv){ifstream f(argv[1]);limit=argc>2?stoll(argv[2]):0;f>>L>>R;
 int nl,nr;f>>nl>>nr;if(nr>63||L>40||R>40)return 2;
 vector<Counts> leftDesign(nl);rightDesign.resize(nr);for(auto&row:leftDesign)for(int j=0;j<L;j++)f>>row[j];
 for(int k=0;k<nr;k++)for(int j=0;j<R;j++){f>>rightDesign[k][j];for(int z=0;z<=rightDesign[k][j];z++)permits[j][z]|=Bits(1)<<k;}
 Choice x;
 int H[14][14]={},K[14][14]={};
 for(auto P:{&H,&K})for(int i=0;i<14;i++)for(int j=i+1;j<14;j++){f>>(*P)[i][j];(*P)[j][i]=(*P)[i][j];}
 struct Block{int i,j;vector<int>B,C;};vector<Block> blocks;
 int i;while(f>>i&&i>=0){Block b;b.i=i;int m;f>>b.j>>m;b.B.resize(m);for(int&v:b.B)f>>v;f>>m;b.C.resize(m);for(int&v:b.C)f>>v;blocks.push_back(b);}
 vector<vector<int>> pattern;
 int m,n,t;while(f>>m>>n>>t){vector<string>tabs(t);for(auto&z:tabs)f>>z;
 for(auto &b:blocks)if((int)b.B.size()==m&&(int)b.C.size()==n)for(auto &z:tabs){
  Choice v={};v.s=b.i;v.t=b.j;opts.push_back(v);vector<int> p;int j=0;
  for(int x:b.B)for(int y:b.C)p.push_back(4*(14*x+y)+z[j++]-'0');pattern.push_back(p);
 }}
 if(opts.size()>64*MAX)return 2;
 Set allowed={};compat.resize(opts.size());vector<Set> conflicting(4*196);
 for(int i=0;i<(int)opts.size();i++){Bits bit=Bits(1)<<(i%64);allowed[i/64]|=bit;dom[opts[i].s][i/64]|=bit;revdom[opts[i].t][i/64]|=bit;
  for(int v:pattern[i]){
   int a=v/4/14,b=v/4%14,c=v%4;
   for(int k=1;k<4;k++)if(k!=c)conflicting[4*(14*a+b)+k][i/64]|=bit;
   for(int j=0;j<14;j++){
    if(j!=a && H[a][j]==c)conflicting[4*(14*j+b)+c][i/64]|=bit;
    if(j!=b && K[b][j]==c)conflicting[4*(14*a+j)+c][i/64]|=bit;
   }
  }
 }
 nb=(opts.size()+63)/64;
 for(int i=0;i<(int)opts.size();i++){compat[i]=allowed;for(int v:pattern[i])for(int b=0;b<nb;b++)compat[i][b]&=~conflicting[v][b];}
 for(int k=0;k<nl;k++){auto active=allowed;for(int i=0;i<L;i++)if(!leftDesign[k][i])for(int b=0;b<nb;b++)active[b]&=~dom[i][b];
 Counts used={};nodes=0;bool yes=search(active,leftDesign[k],used,(Bits(1)<<nr)-1,0);
 cout<<k<<" "<<(yes?"SAT":limit>0&&nodes>limit?"UNKNOWN":"UNSAT")<<" "<<nodes<<endl;if(yes)break;}
}

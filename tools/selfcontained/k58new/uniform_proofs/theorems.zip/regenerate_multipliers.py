"""Optional certificate regeneration using SciPy. The checker itself uses only integers."""
from multiplicity import HERE, spectra, system, verify
import json
from fractions import Fraction
from math import lcm,gcd
from functools import reduce
import numpy as np
from scipy.optimize import linprog
out=[]
for n in spectra():
 G,h=system(n)
 A=[[-z for z in t]for t in zip(*G)]+[h];b=[0]*(len(A)-1)+[-1]
 r=linprog(np.ones(len(h)),A_ub=A,b_ub=b,bounds=(0,None),method='highs')
 assert r.success,(n,r.message)
 vals=[Fraction(float(v)).limit_denominator(100000) for v in r.x]
 d=lcm(*(v.denominator for v in vals));y=[int(v*d) for v in vals];g=reduce(gcd,y);y=[v//g for v in y]
 assert min(y)>=0 and sum(a*b for a,b in zip(y,h))<0
 assert all(sum(a*b for a,b in zip(y,g))>=0 for g in zip(*G))
 out.append({'counts':n,'weights':y})
(HERE/'multiplicity-certs.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
verify()

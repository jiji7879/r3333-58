"""Exhaust the partition design against the pinned twisted template."""
from model import *
A0=range(15)
def mat(T,S):return tuple(tuple(T[i][j] if i!=j else 0 for j in S)for i in S)
def invariant(T):
 return tuple(sorted(tuple(r.count(c)for c in (1,2,3)) for r in T))
def iso(M,N):
 n=len(M);dg=lambda r:tuple(r.count(c) for c in (1,2,3));q=[[j for j in range(n)if dg(M[i])==dg(N[j])]for i in range(n)]
 match={}
 def branch():
  if len(match)==n:yield tuple(match[i]for i in range(n));return
  _,i,opts=min((len(x),i,x)for i in range(n)if i not in match for x in [[j for j in q[i]if j not in match.values() and all(M[i][u]==N[j][v]for u,v in match.items())]])
  for j in opts:
   match[i]=j;yield from branch();del match[i]
 yield from branch()
@lru_cache(None)
def alphabet():
 pool={}
 for T in (A,U):
  for P in combinations(A0,5):
   if any(T[i][j]==1 for i,j in combinations(P,2)):continue
   Q=sorted(set(A0)-set(P));N=mat(T,Q);graph={ij:T[ij[0]][ij[1]]for ij in combinations(P,2)}
   perm=order(P,graph);pp=[]
   for direction in (-1,1):
    for start in range(5):
     pp.append(tuple(perm[(start+direction*i)%5]for i in range(5)))
   pool.setdefault(invariant(N),[]).append((T,Q,N,pp))
 out={}
 for L in combinations(A0,5):
  Q=sorted(set(A0)-set(L));M=mat(A,Q);mask=sum(1<<a for a in L);pins=set()
  for T,V,N,pp in pool.get(invariant(M),[]):
   for image in iso(M,N):
    for o in pp:
     rows=tuple(tuple(sum(1<<a for a,j in zip(Q,image)if T[b][V[j]]==c)if c else mask for c in range(4))for b in o)
     pins.add(rows)
  if pins:out[mask]=list(pins)
 return out
@lru_cache(None)
def words(mask):
 W=[]
 def gen(a,parts):
  if a==15:W.append(tuple(parts));return
  if mask>>a&1:gen(a+1,parts);return
  for c in (1,2,3):
   if not any(parts[c]>>v&1 and A[a][v]==c for v in range(a)):
    parts[c]|=1<<a;gen(a+1,parts);parts[c]^=1<<a
 gen(0,[mask,0,0,0]);return W
def test(idx,sw,vectors):
 g=GRAPHS[idx];pal=(0,2,3)if not sw else(0,3,2);H={e:pal[int(c)]for e,c in zip(combinations(range(14),2),g)}
 ss=supports(g);m=vectors[idx][0];assert sorted(x for x in m if x)==[5,5,5]
 blocks=sorted((S for S,k in zip(ss,m)if k),key=len,reverse=True);B,C,D=[order(S,H)for S in blocks]
 eg=lambda i,j:H[tuple(sorted((i,j)))]
 choices=alphabet();tot=[0]*5
 assert sorted([x for b in blocks for x in b])==list(range(14))
 for G,first in choices.items():
  for K,second in choices.items():
   if G&K:continue
   tot[0]+=1
   for t in first:
    for s in second:
     tot[1]+=1
     if any(t[i][eg(x,y)]&s[j][eg(x,y)]for i,x in enumerate(B)for j,y in enumerate(C)):continue
     tot[2]+=1;placed=dict(zip(B,t))|dict(zip(C,s));w=words(32767^G^K)
     def rec(p):
      if p==4:
       tot[4]+=1;return
      x=D[p]
      for v in w:
       if all(not (u[eg(x,y)]&v[eg(x,y)])for y,u in placed.items()):
        placed[x]=v;rec(p+1);del placed[x]
     rec(0)
 assert tot == [330,33000,22,0,0], (idx,sw,tot)
 return tot

"""Independent search in Python using a cross-edge literal index and fixed sender order."""
from model import *

def solve(H, B, K, C):
    left, right = Counter(B), Counter(C)
    slots = sorted(left.elements(), key=lambda s:(sum(len(t)+len(s)>8 for t in right),s))
    options=[]
    sources={}
    targets={t:0 for t in right}
    literal={}
    forbidden={}
    for s in left:
        mask=0
        for t in right:
            if (len(s),len(t)) not in SHAPES:
                continue
            cells=[(x,y) for x in order(s,H) for y in order(t,K)]
            for v in tables(len(s),len(t)):
                pat=tuple((x,y,c) for (x,y),c in zip(cells,v))
                flag=1<<len(options)
                for p in pat:literal[p]=literal.get(p,0)|flag
                options.append((t,pat));mask|=flag;targets[t]|=flag
        sources[s]=mask
    for x,y,c in literal:
        illegal=[(x,y,a) for a in (1,2,3) if a!=c]
        illegal.extend((u,y,c) for u in range(14) if x!=u and H[pair(u,x)]==c)
        illegal.extend((x,v,c) for v in range(14) if y!=v and K[pair(y,v)]==c)
        block=0
        for p in illegal:block|=literal.get(p,0)
        forbidden[x,y,c]=block
    @lru_cache(None)
    def reject(idx):
        mask=0
        for p in options[idx][1]:mask|=forbidden[p]
        return mask
    path=[]
    def dfs(depth,allowed):
        if depth==len(slots):
            assert sum(right.values())==0
            board={}
            for idx in path:
                for x,y,c in options[idx][1]:
                    assert board.setdefault((x,y),c)==c
            for (x,y),c in board.items():
                assert all(u==x or H[pair(x,u)]!=c or board.get((u,y))!=c for u in range(14))
                assert all(v==y or K[pair(y,v)]!=c or board.get((x,v))!=c for v in range(14))
            return True
        s=slots[depth]
        if any(not (allowed&sources[u]) for u in set(slots[depth:])):return False
        if any(n and not (allowed&targets[t]) for t,n in right.items()):return False
        candidates=allowed&sources[s]
        if depth and slots[depth-1]==s:
            candidates&=-(1<<path[-1])
        while candidates:
            bit=candidates & -candidates
            candidates-=bit
            idx=bit.bit_length()-1
            t=options[idx][0]
            assert right[t]>0
            right[t]-=1
            path.append(idx)
            after=allowed&~reject(idx)
            if right[t]==0:after&=~targets[t]
            if dfs(depth+1,after):return True
            path.pop()
            right[t]+=1
        return False
    return dfs(0,(1<<len(options))-1)

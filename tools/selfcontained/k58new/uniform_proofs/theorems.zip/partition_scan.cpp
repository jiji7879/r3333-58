#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

using Row = std::array<int,4>;
using Five = std::array<Row,5>;
using Bits = std::uint64_t;
struct Pair { int a,b,rest; };
using SmallBoard = std::array<std::array<int,14>,14>;
using Domains = std::array<std::vector<const Row*>,4>;

bool finish(const SmallBoard& h, const Domains& allowed, std::array<const Row*,4>& chosen, int n) {
    if(n==4) return true;
    for(const Row* w:allowed[n]){
        bool ok=true;
        for(int j=0;j<n;j++){
            int c=h[10+j][10+n];
            if((*chosen[j])[c] & (*w)[c]){ ok=false;break; }
        }
        if(ok){
            chosen[n]=w;
            if(finish(h,allowed,chosen,n+1)) return true;
        }
    }
    return false;
}
int main(){
    int n;std::cin>>n;
    std::vector<int> zero(n);
    std::vector<Five> alphabet(n);
    for(int i=0;i<n;i++){
        std::cin>>zero[i];
        for(auto &v:alphabet[i])for(int &part:v)std::cin>>part;
    }
    std::vector<std::vector<Row>> words(32768);
    int count;std::cin>>count;
    for(int i=0;i<count;i++){
        int mask,size;std::cin>>mask>>size;words[mask].resize(size);
        for(auto& w:words[mask])for(int& c:w)std::cin>>c;
    }
    std::vector<Pair> pairs;
    for(int a=0;a<n;a++)for(int b=0;b<n;b++)if(!(zero[a]&zero[b])){
        pairs.push_back({a,b,32767^zero[a]^zero[b]});
    }
    assert(pairs.size()==33000);
    const int blocks=(pairs.size()+63)/64;
    std::array<std::array<std::array<std::vector<Bits>,4>,5>,5> allowed;
    for(auto &r:allowed)for(auto &s:r)for(auto &c:s)c.assign(blocks,0);
    for(int k=0;k<(int)pairs.size();k++){
        auto [a,b,w]=pairs[k];
        for(int i=0;i<5;i++)for(int j=0;j<5;j++)for(int c:{0,2,3})
            if(!(alphabet[a][i][c]&alphabet[b][j][c]))
                allowed[i][j][c][k/64]|=Bits(1)<<(k%64);
    }
    int t,flip,p;
    while(std::cin>>t>>flip>>p){
        SmallBoard H{};
        for(int i=0;i<14;i++)for(int j=i+1;j<14;j++){
            std::cin>>H[i][j];H[j][i]=H[i][j];
        }
        std::vector<Bits> candidates(blocks,~Bits(0));
        for(int i=0;i<5;i++)for(int j=0;j<5;j++){
            auto &keep=allowed[i][j][H[i][5+j]];
            for(int k=0;k<blocks;k++)candidates[k]&=keep[k];
        }
        int witness=-1;
        std::array<const Row*,4> chosen{};
        for(int k=0;k<blocks && witness<0;k++)for(Bits todo=candidates[k];todo;todo&=todo-1){
            int id=64*k+__builtin_ctzll(todo);
            auto [a,b,mask]=pairs[id];
            Domains domains;bool empty=false;
            for(int u=0;u<4;u++){
                for(const Row& w:words[mask]){
                    bool ok=true;
                    for(int j=0;j<5;j++){
                        int c=H[j][10+u],d=H[5+j][10+u];
                        if((alphabet[a][j][c]&w[c]) || (alphabet[b][j][d]&w[d])){ok=false;break;}
                    }
                    if(ok)domains[u].push_back(&w);
                }
                if(domains[u].empty()){empty=true;break;}
            }
            if(!empty && finish(H,domains,chosen,0)){witness=id;break;}
        }
        std::cout<<t<<" "<<flip<<" "<<p<<" "<<witness;
        if(witness>=0){
            auto [a,b,w]=pairs[witness];
            for(auto& v:alphabet[a])for(int z:v)std::cout<<" "<<z;
            for(auto& v:alphabet[b])for(int z:v)std::cout<<" "<<z;
            for(auto v:chosen)for(int z:*v)std::cout<<" "<<z;
        }
        std::cout<<"\n";
    }
}

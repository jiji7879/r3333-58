from itertools import combinations

def supports(graph):
 H={e:int(c) for e,c in zip(combinations(range(14),2),graph)}
 cols=[]
 for n in (4,5):
  for S in combinations(range(14),n):
   colours=[H[e]for e in combinations(S,2)]
   if 0 not in colours and (n==5 or colours.count(1)==3):
    cols.append(S)
 return cols

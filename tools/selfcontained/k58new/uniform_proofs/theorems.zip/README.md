# Repeated zero neighbourhoods and compatibility between Ramsey arms

In the fully sending uniform branch of the rooted triangle-free four-colouring of K₅₈, the 42 outside vertices must realize **at least 12 distinct five-element sets of zero neighbours** in the 15-arm. At most **three** different sets can each occur five or more times. Both conclusions allow the outside vertices to lie anywhere in the three 14-arms and to use all four colours in their words. The overlap proof applies to either template on the 15-arm.

For the twisted 15-arm, the finite checks also exclude **51 unordered pairs of 14-arm types** and **2,955 of 3,093** specified partitions of a 14-arm. These are subcases of the seven uniform children. All seven remain open. The previously proved lower bound of 33 outside vertices using all four colours still stands.

## 1. A colour-omitting set from two repeated neighbourhoods

Let r be the root, A its colour-0 neighbourhood of size 15, and B, C, D its other neighbourhoods of size 14. There are no zero edges inside A. For each outside vertex x, write Z(x) for its five zero neighbours in A. For a five-set L contained in A let X(L) be the outside vertices with Z(x) = L, in all arms combined, and let p(L) be its size.

The set X(L) together with A minus L omits colour 0. Its order is p(L) + 10. Since a triangle-free three-colouring has at most 16 vertices, **p(L) ≤ 6**. Only the upper bound is needed. In a three-colouring on 17 vertices, some vertex has six neighbours in one colour. Their internal edges must use the other two colours, contradicting R(3,3) = 6.

For distinct L, M with t = |L ∩ M| > 0, every edge inside X(L) ∪ X(M) avoids 0. Its endpoints have a common zero neighbour in A. Every edge from these classes to A outside L ∪ M also avoids 0. The resulting three-coloured set has order

    p(L) + p(M) + 15 − (10 − t) = p(L) + p(M) + 5 + t.

Consequently **p(L) + p(M) + t ≤ 11** whenever L and M meet. If the classes are disjoint groups of chosen vertices with the same five-set, the same argument with t = 5 gives the corresponding bound on their combined size. For several distinct classes whose five-sets meet pairwise, the union of their vertices together with A outside the union of their five-sets again omits 0.

**At most three distinct five-sets can have multiplicity at least five.** Any two such five-sets meet in at most one point. Join intersecting five-sets by an edge. A triangle would give 15 outside vertices all joined by nonzero edges. The union of the three five-sets has size at most 13, since two successive nonempty intersections already save two points. Adding two vertices of A would give a three-coloured K₁₇. The intersection graph is therefore triangle-free. On four vertices it has at most four edges. Four five-sets would then cover at least 20 − 4 = 16 points of A, a contradiction. In particular, a sixfold class is disjoint in A from every other class of multiplicity at least five.

**A restriction on the other two arms.** Suppose B splits into groups of sizes 5, 5, 4, each group having a shared five-set, and their three five-sets partition A. Any five vertices in C ∪ D sharing the same five-set M would meet those three sets in at most 1, 1, 2 points by the two-class argument. This also covers equality of the five-sets, using disjoint groups of vertices. Since |M| = 5, this is impossible. Thus every five-set occurs at most four times across C and D together. In particular two arms cannot both have this partition form. The proof uses only the classical bound R(3,3,3) = 17.

**A sender must see at least three different five-sets.** Fix a in A. Its 14 outside zero neighbours form a zero-free set. Any point of A outside the union of the five-sets of those neighbours can be added to that set. Their union must consequently cover at least 13 points of A. All those five-sets contain a. Two can cover at most nine points. If there are exactly three, they must be disjoint off a to reach thirteen.

## 2. Why at least twelve different five-sets are needed

Write nⱼ for the number of distinct five-sets occurring j times, for 1 ≤ j ≤ 6. Then Σ j nⱼ = 42 and n₅ + n₆ ≤ 3. Eight or fewer sets can account for at most 8·4 + 3·2 = 38 vertices. There is one multiplicity vector with nine sets, fifteen with ten, and fifty-five with eleven, for 71 in total.

For a sender a in A, let uⱼ count how many of these j-fold sets contain a. In the uniform branch a has exactly fourteen outside zero neighbours, so Σ j uⱼ = 14. Also 0 ≤ uⱼ ≤ nⱼ. At most two fivefold sets meet at a, and any sixfold set at a precludes all other fivefold or sixfold sets there. Let xᵤ count senders of each allowed vector u. We need Σ xᵤ = 15 and Σ uⱼ xᵤ = 5nⱼ for every j.

For two distinct sets of multiplicities i, j their intersection has size at most

    c(i,j) = max(0, min(4, 11 − i − j)).

Counting intersections over senders gives Σ uᵢ uⱼ xᵤ ≤ c(i,j) nᵢ nⱼ for i ≠ j. For i = j replace each product with the corresponding binomial coefficient of order two. Finally Σ [u₅ = 2] xᵤ ≤ floor(n₅²/4), since the intersection graph on at most three fivefold sets is triangle-free and each of its edges represents just one sender.

For **each of the 71 vectors**, a nonnegative integer combination of these inequalities gives a contradiction. The file multiplicity-certs.json stores the multipliers. The short standard-library checker in multiplicity.py first generates all 71 vectors and their inequalities Gx ≤ h. It checks y ≥ 0, yG ≥ 0 and yh < 0 with integer arithmetic for each supplied y. This even excludes real nonnegative x for these 71 cases. Twelve is a lower bound; the proof makes no claim that an actual colouring attains twelve.

## 3. Which arm types are incompatible

The IDs are zero-based in the supplied rooted K₁₄ catalogue. Colour 0 is distinguished. Each arm also omits its own root colour. Both orientations of the other two colours are allowed.

| One arm has type | Types excluded on a different arm | Unordered pairs |
| --- | --- | ---: |
| 2, 11, 13, 31, 39, 46 | Any of the same six, including equal types | 21 |
| 2, 11, 13, 31, 39, 46 | 43, 72, 155, 165, 229 | 30 |

The root colour and the names of the arms can be permuted. The checker verifies that all ordinary-colour permutations transport to point permutations of the two classified 15-templates. No assumption on the number of omitted word colours is used here.

For each sender a the fourteen outside vertices joined to a in colour 0, together with r, induce one of the two three-coloured K₁₅ templates. The sets of its zero neighbours in B, C, D therefore have sizes 4, 5, 5 in some order. The four induce complementary paths and the fives induce complementary cycles in their two allowed colours. Each vertex of an arm occurs in five sender supports. This forces exactly five supports of size four and ten of size five per arm. Exhaustive integer multiplicity enumeration gives 2, 5, 5, 1, 2 and 1 support multisets for the six IDs in the first row, respectively. The other five IDs each give 42.

For the pair B, C, normalize their root colours to 1, 2. Order each support along its colour-3 path or cycle. At one sender the cross edges of colour 3 match every vertex on the smaller side. For any two matched pairs, exactly one of the two internal edges between their endpoints is colour 3. In particular the colour-3 graph on a 5-by-5 pair of supports is the Petersen graph. In each of the shapes 4-by-5, 5-by-4 and 5-by-5 there are precisely **ten** labelled matchings and **six** complete colour tables per matching. These counts come from enumerating both templates at every possible root, including all orderings along the paths and cycles.

Choose one full table for each of the 15 senders. Its support choices must have the prescribed multiplicities. Every table using the same cross edge must assign it the same colour. A pair of chosen tables must also avoid monochromatic triangles using an internal edge of either fixed arm. The backtracking search branches on every compatible table and every possible relative pairing of supports, including repeated supports. A full colouring would yield such a choice. Uncovered edges can be left free for this necessity test.

For the first six types, 494 of the 528 unordered pairs of oriented support systems already fail this test. Every one of the 34 survivors uses the partition design on type 11 or 13. Section 4 excludes these designs even before the second arm is fixed. A separate grouped search checks all 30 further type pairs after the same single-arm partition test. It retains every right-hand support multiset whose capacities accommodate the partial table choices. A Python implementation with different branching reproduces one feasible and one infeasible fixed-design example. The 51 exclusions do not assert that any individual type is impossible with arbitrary partners.

## 4. A catalogue-wide test of the partition pattern

Enumerate all 0-free internal 5-cycles, 5-cycles and 4-paths partitioning the labelled vertices of each catalogue representative, with the two five-blocks unordered. There are **3,093** partitions on **291** of the 332 representatives. This counts choices of vertex subsets in the supplied labels, without a further quotient by automorphisms of an individual arm. An occurrence of the partition design makes every vertex of a block share one five-set of senders, and the three sender sets partition A.

For a five-block P with shared five-set L, the vertices P ∪ (A minus L) induce a three-coloured K₁₅. For the pinned twisted A, enumeration on the two classified templates leaves only 66 possible L, with ten labelled joins on each. For the ordered pair of five-blocks there are 330 disjoint ordered choices of their five-sets and 33,000 choices of their joined rows. Reject an assignment if it creates a monochromatic triangle with an edge between the blocks. For each of the four remaining vertices enumerate every word with the prescribed third five-set as its zeros, and check all triangles against A and the other placed vertices.

Exactly **138** of the 3,093 partitions admit a local join, on **65** catalogue types. Both palette orientations give the same result for each partition. The other **2,955** are excluded. The verifier checks a full labelled join, including all edge colours and triangles, for each of the 276 surviving orientations. These witnesses reach r ∪ A ∪ B of order 30. For types 11 and 13 a second implementation verifies the finer intermediate counts: 22 of the 33,000 assignments pass the test between the two five-blocks, and none accepts all four remaining vertices. All partition designs on the eleven types in Section 3 fail.

## 5. Which colours can be omitted

In the twisted branch, at least **13 of the 14** vertices of each small arm use their own root colour somewhere in their word into A. Equivalently, at least 39 of the 42 vertices use their respective root colour. To check this for B, take its colour as 1. Only six of the eighteen possible colour-omitting words miss colour 1. Compare all compatible pairs, with repetitions permitted. Verified point and palette symmetries reduce these pairs to (0,1), (0,3) and (0,4) in the word ordering in data.py. A full local search on all 332 catalogue arms in both orientations rules out all three. The search checks the shape of every sender support, five zeros per outside vertex, and all monochromatic triangles. Transport by colour permutations gives the other two arms. This sharpens which colours can be missing while leaving open whether 34 full words are forced.

## Replay and inputs

Run from this directory with Python 3.10+ and a C++17 compiler supporting unsigned 128-bit integers.

    python3 verify.py --jobs 4

For just the 71 arithmetic certificates, run the following command. It needs only Python.

    python3 -c "from multiplicity import verify; verify()"

REPLAY.txt records the complete package replay. The base catalogue and both canonical 15-templates are project inputs. All additional tables, multiplicity vectors, joins and type-pair checks can be rebuilt offline with the supplied code. These finite enumerations use exhaustive backtracking; the arithmetic certificates are independent integer identities. A globally valid K₅₈ and a closure of any full uniform child remain open.

[Project K₁₄ catalogue and K₁₅ classification, pinned revision](https://github.com/jiji7879/r3333-58/tree/aeee53acda706e4cec6e6b0101257d58ceb84369/results/arm-alphabet-14) · [Uniform-child hypotheses](https://github.com/jiji7879/r3333-58/blob/aeee53acda706e4cec6e6b0101257d58ceb84369/review/PROFILE_15141414_STATE.md) · [Greenwood–Gleason bound](https://www.mathstat.dal.ca/FQ/Scanned/22-3/sun.pdf)

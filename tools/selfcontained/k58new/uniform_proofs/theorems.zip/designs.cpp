#include <algorithm>
#include <array>
#include <iostream>
#include <vector>
using namespace std;
using Board=array<int,15>;using Mask=unsigned __int128;
struct Kernel{
 long long solutions=0;vector<int> multiplicity;vector<int> supports; array<Mask,15> through{}; unsigned long long nodes=0;
 static int first(Mask m){auto low=(unsigned long long)m;return low?__builtin_ctzll(low):64+__builtin_ctzll((unsigned long long)(m>>64));}
 bool search(Board &r,Mask free){
  ++nodes; int row=-1; unsigned long long best=~0ULL;
  for(int i=0;i<15;i++)if(r[i]==0)free&=~through[i];
  for(int i=0;i<15;i++)if(r[i]){
   Mask available=free&through[i];int n=__builtin_popcountll((unsigned long long)available)+__builtin_popcountll((unsigned long long)(available>>64));if(!n)return false;
   unsigned long long ways=1;for(int j=1;j<=r[i];j++)ways=ways*(n+j-1)/j;
   if(ways<best){row=i;best=ways;}
  }
  if(row<0){solutions++;for(int m:multiplicity)cout<<m<<" ";cout<<"\n";return solutions>=100;}
  return assign(r,free&through[row],free&~through[row],r[row]);
 }
 bool assign(Board &r,Mask opts,Mask other,int left){
  if(!left)return search(r,other);
  if(!opts)return false;
  int j=first(opts),sites=supports[j],top=left;opts&=opts-1;
  for(int z=sites;z;z&=z-1)top=min(top,r[__builtin_ctz((unsigned)z)]);
  for(int n=top;n>=(opts?0:left);--n){
   for(int z=sites;z;z&=z-1)r[__builtin_ctz((unsigned)z)]-=n;
   multiplicity[j]=n;bool ok=assign(r,opts,other,left-n);multiplicity[j]=0;
   for(int z=sites;z;z&=z-1)r[__builtin_ctz((unsigned)z)]+=n;
   if(ok)return true;
  }
  return false;
 }
};
int main(){
 int row,n;while(cin>>row>>n){if(n<1||n>=128)return 2;Kernel k;
  for(int i=0;i<n;i++){int sites;cin>>sites;k.supports.push_back(sites);for(int z=sites;z;z&=z-1)k.through[__builtin_ctz((unsigned)z)]|=Mask(1)<<i;}
  k.multiplicity.assign(n,0);Board r;r.fill(5);bool solution=k.search(r,(Mask(1)<<n)-1);cout<<row<<" "<<k.solutions<<" "<<k.nodes<<endl;
 }
}

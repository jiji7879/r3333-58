"""Disjoint five, five and four-vertex supports, each repeated five times."""
from model import *

@lru_cache(None)
def partitions(i):
    sets=supports(GRAPHS[i])
    four={frozenset(s) for s in sets if len(s)==4}
    five=[frozenset(s) for s in sets if len(s)==5]
    whole=frozenset(range(14))
    out=[]
    for s,t in combinations(five,2):
        if s.isdisjoint(t) and whole-s-t in four:
            out.append(tuple(tuple(sorted(v)) for v in (s,t,whole-s-t)))
    return out

if __name__=='__main__':
    rows={i:partitions(i) for i in range(332)}
    print(Counter(map(len,rows.values())))
    print(sum(map(len,rows.values())))

def scan(tmp):
    from blocks import alphabet, words
    from subprocess import run
    exe=tmp/'partition_scan'
    run(['c++','-std=c++17','-O3',str(HERE/'partition_scan.cpp'),'-o',exe],check=True)
    data=tmp/'partitions.in'
    views={}
    with data.open('w') as f:
        a=alphabet()
        print(sum(map(len,a.values())),file=f)
        for mask,opts in sorted(a.items()):
            for t in sorted(opts):
                print(mask,*[c for row in t for c in row],file=f)
        masks=sorted({32767^l^r for l in a for r in a if not (l&r)})
        print(len(masks),file=f)
        for mask in masks:
            ws=words(mask)
            print(mask,len(ws),file=f)
            for row in ws:print(*row,file=f)
        for i in range(332):
            for flip in (0,1):
                H=labelled_arm(i,1,flip)
                for p,parts in enumerate(partitions(i)):
                    order14=sum([order(s,H) for s in parts],[])
                    edges=[H[pair(order14[u],order14[v])] for u,v in EDGES]
                    print(i,flip,p,*edges,file=f)
                    views[i,flip,p]=(order14,edges)
    with data.open() as f:
        result=run([exe],stdin=f,capture_output=True,text=True,check=True)
    outcomes={}
    for line in result.stdout.splitlines():
        row=list(map(int,line.split()))
        key=tuple(row[:3]);idx,flip,p=key
        assert key in views and key not in outcomes
        yes=row[3]>=0;outcomes[key]=yes
        if yes:
            assert len(row)==60
            masks=[row[4+j:8+j] for j in range(0,56,4)]
            assert all(sum(v)==32767 and all(not (a&b) for a,b in combinations(v,2)) for v in masks)
            assert all(m[0].bit_count()==5 for m in masks)
            assert len({m[0] for m in masks[:5]})==len({m[0] for m in masks[5:10]})==len({m[0] for m in masks[10:]})==1
            assert sorted([masks[0][0]|masks[5][0]|masks[10][0]])==[32767]
            for m in masks:
                assert all(not ((m[A[a][b]]>>a)&(m[A[a][b]]>>b)&1) for a,b in combinations(range(15),2))
            pi,edges=views[key]
            assert all(not (masks[u][c]&masks[v][c]) for (u,v),c in zip(EDGES,edges))
    assert set(views)==set(outcomes) and len(outcomes)==6186
    return outcomes


"""Replay the arm exclusions using Python 3.10+ and a C++17 compiler."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from itertools import combinations_with_replacement
import subprocess
from tempfile import TemporaryDirectory
from model import *
from blocks import alphabet, test as partition_test
from symmetry import isos
from data import palette_maps, omitting_words, candidate_multisets

def run(args, **kwargs):
    return subprocess.run(list(map(str,args)),capture_output=True,text=True,check=True,**kwargs).stdout

def compile_all(tmp):
    for name in ('designs', 'full', 'group', 'local2'):
        run(['c++','-O3','-std=c++17',HERE/(name+'.cpp'),'-o',tmp/name])

def designs(tmp):
    result={}
    for idx,n in EXPECTED.items():
        cols=supports(GRAPHS[idx])
        masks=[sum(1<<v for v in s) + ((1<<14) if len(s)==4 else 0) for s in cols]
        lines=run([tmp/'designs'],input=' '.join(map(str,[idx,len(masks),*masks]))+'\n').splitlines()
        i,total,nodes=map(int,lines[-1].split())
        vs=[tuple(map(int,line.split())) for line in lines[:-1]]
        assert i==idx and total==n==len(set(vs))==len(vs)<100
        for v in vs:
            assert len(v)==len(cols) and min(v)>=0 and sum(v)==15
            assert all(sum(z for z,s in zip(v,cols) if w in s)==5 for w in range(14))
            assert sum(z for z,s in zip(v,cols) if len(s)==4)==5
        result[idx]=vs
    return result

def own_colour(tmp,workers):
    W=omitting_words(A)
    own=[i for i,w in enumerate(W) if not w[1]]
    feasible=[p for p in candidate_multisets(W,2) if set(p)<=set(own)]
    perms=[]
    for p in ((0,1,2,3),(0,1,3,2)):
        for v in isos(A,A,p):
            rec=[]
            for w in W:
                image=[0]*4
                for c in range(4):
                    image[p[c]]=sum(1<<v[j] for j in range(15) if w[c]>>j&1)
                rec.append(W.index(tuple(image)))
            perms.append(rec)
    reps=sorted({min(tuple(sorted(s[i] for i in t)) for s in perms) for t in feasible})
    assert len(own)==6 and reps==[(0,1),(0,3),(0,4)]
    (tmp/'graphs.txt').write_text('\n'.join(GRAPHS)+'\n')
    path=tmp/'own.in'
    with path.open('w') as f:
        for w in W:print(*w,file=f)
        for p in reps:print(2,*p,file=f)
    def check(lo):
        hi=min(332,lo+42)
        log=run([tmp/'local2',path,1,2,lo,hi,HERE/'T.col'],cwd=tmp)
        assert log==(HERE/f'ownpair_{lo}.log').read_text() and log.strip().endswith(', 0 feasible pattern-orientation pairs')
    with ThreadPoolExecutor(workers) as pool:list(pool.map(check, range(0,332,42)))
    print('Own-colour omission pairs excluded on 332 types and both orientations.',flush=True)

def write_fixed(path, job, allsets):
    i,d,f,j,e,g=job
    H,K=labelled_arm(i,1,f),labelled_arm(j,2,g)
    B,C=allsets[i][d],allsets[j][e]
    L,R=sorted(set(B)),sorted(set(C))
    with path.open('w') as out:
        print(len(L),len(R),file=out)
        print(*[B.count(s) for s in L],file=out)
        print(*[C.count(s) for s in R],file=out)
        write_tail(out,H,K,L,R)

def fixed_pairs(tmp,allsets,workers):
    entries={}
    for line in (HERE/'pair-ledger.txt').read_text().splitlines():
        w=line.split()
        key=tuple(map(int,w[:6]))
        assert key not in entries
        entries[key]=w[6:]
    systems=[(i,d,f) for i in (31,46,2,39,11,13) for d in range(len(allsets[i])) for f in (0,1)]
    assert set(entries)=={left+right for left,right in combinations_with_replacement(systems,2)}
    assert len(entries)==528
    def check(job):
        with TemporaryDirectory(dir=tmp) as d:
            p=Path(d)/'instance'
            write_fixed(p,job,allsets)
            words=run([tmp/'full',p]).split()
            assert words==entries[job]
            i,d,_,j,e,_=job
            if words[0]=='SAT':
                assert (i in (11,13) and d==0) or (j in (11,13) and e==0)
            return words[0]
    with ThreadPoolExecutor(workers) as pool: result=Counter(pool.map(check,entries))
    assert result=={'UNSAT':494,'SAT':34}
    print('Reproduced 528 fixed-design results. Each of the 34 feasible pairs uses a forbidden partition design.',flush=True)

def grouped_input(path,job,allsets):
    i,f,j,g=job
    H,K=labelled_arm(i,1,f),labelled_arm(j,2,g)
    B,C=[[v for v in allsets[k] if sorted(Counter(v).values())!=[5,5,5]] for k in (i,j)]
    L,R=[sorted({s for d in ds for s in d}) for ds in (B,C)]
    with path.open('w') as out:
        print(len(L),len(R),len(B),len(C),file=out)
        for ds,cols in ((B,L),(C,R)):
            for d in ds:print(*[d.count(s) for s in cols],file=out)
        write_tail(out,H,K,L,R)

def mixed(tmp,allsets,workers):
    pairs=[tuple(map(int,line.split())) for line in (HERE/'mixed-pairs.txt').read_text().splitlines() if line.strip()]
    assert set(pairs)=={(i,j) for i in SMALL for j in (43,72,155,165,229)} and len(pairs)==30
    jobs=[(i,f,j,g) for i,j in pairs for f in (0,1) for g in (0,1)]
    def check(job):
        with TemporaryDirectory(dir=tmp) as d:
            p=Path(d)/'instance'
            grouped_input(p,job,allsets)
            reply=run([tmp/'group',p])
            rows=[l.split() for l in reply.splitlines()]
            assert [int(r[0]) for r in rows]==list(range(sum(sorted(Counter(v).values())!=[5,5,5] for v in allsets[job[0]])))
            assert all(r[1]=='UNSAT' for r in rows)
    with ThreadPoolExecutor(workers) as pool:list(pool.map(check,jobs))
    print(f'Replayed {len(pairs)} further excluded type pairs in all four palette orientations.',flush=True)

def main():
    if not __debug__:raise RuntimeError('Keep assertions enabled.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jobs',type=int,default=4)
    parser.add_argument('stages',nargs='*',help='base, fixed, mixed, own, independent, partitions, multiplicity (default: all)')
    args=parser.parse_args()
    stages=set(args.stages or ['base','fixed','mixed','own','independent','partitions','multiplicity'])
    assert 0<args.jobs and stages<={'base','fixed','mixed','own','independent','partitions','multiplicity'}
    with TemporaryDirectory() as d:
        tmp=Path(d)
        compile_all(tmp)
        # A colour permutation can be transported by an actual point permutation.
        for T in (A,U):palette_maps(T,[])
        for shape in SHAPES:tables(*shape)
        print('Verified ten complementary matchings, six full tables per matching, for each support shape.',flush=True)
        ds=designs(tmp)
        allsets={i:multisets_for(i,ds) for i in ds}
        if 'multiplicity' in stages:
            from multiplicity import verify as verify_multiplicity
            verify_multiplicity()
        if 'partitions' in stages or 'mixed' in stages:
            from partitions import scan, partitions
            result=scan(tmp)
            ledger={tuple(map(int,s.split()[:3])):bool(int(s.split()[3])) for s in (HERE/'partition-ledger.txt').read_text().splitlines()}
            assert result==ledger and sum(result.values())==276
            assert all(result[i,0,k]==result[i,1,k] for i in range(332) for k in range(len(partitions(i))))
            assert len({i for (i,f,k),ok in result.items() if ok})==65
            assert not any(ok for (i,f,k),ok in result.items() if i in EXPECTED)
            for i in EXPECTED:
                for v in allsets[i]:
                    if sorted(Counter(v).values())==[5,5,5]:
                        assert len(set().union(*v))==14 and sorted(map(len,set(v)))==[4,5,5]
            print('Enumerated 3,093 partitions. Exactly 138 survive on 65 types. Verified a labelled join for each surviving orientation.',flush=True)
        if 'base' in stages:
            a=alphabet()
            assert len(a)==66 and set(map(len,a.values()))=={10}
            for i in (11,13):
                for f in (0,1):partition_test(i,f,ds)
            print('Partition designs on 11 and 13 excluded in both orientations. Counts 66 / 330 / 33000 / 22 / 0.',flush=True)
        if 'fixed' in stages:fixed_pairs(tmp,allsets,args.jobs)
        if 'mixed' in stages:mixed(tmp,allsets,args.jobs)
        if 'own' in stages:own_colour(tmp,args.jobs)
        if 'independent' in stages:
            from independent import solve
            for i,j,outcome in ((11,11,True),(31,2,False)):
                assert solve(labelled_arm(i,1,0),allsets[i][0],labelled_arm(j,2,0),allsets[j][0])==outcome
            print('Separate Python board search confirmed one compatible and one incompatible fixed pair.',flush=True)

if __name__=='__main__':main()

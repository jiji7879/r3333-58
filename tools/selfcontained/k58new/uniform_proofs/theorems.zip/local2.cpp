#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

using Mask = unsigned __int128;
using Domains = array<Mask,15>;
constexpr int all = (1<<14)-1;
int words[18][4], links[18][18], neighbors[14][16], edge[14][14], A[15][15], wordLetter[18][15];
Mask s4,s5,contain[14];
int positions[12];
ofstream model_file;
bool enumerate_all = false;
int catalogue_index, palette_orientation;
long long nodes, leaves;
int countbits(int s) {return __builtin_popcount((unsigned)s);}
int first(int s) {return __builtin_ctz((unsigned)s);}

// A free outside vertex needs a legal word on A. Domains here already
// incorporate its edges to the distinguished vertices and possible zero supports.
bool star(array<int,15> choices, int todo, int zeros) {
    if(!todo)return zeros==5;
    int slot=-1, best=5, eligible=0,forced=0;
    for(int rem=todo;rem;rem&=rem-1) {
        int i=first(rem),options=choices[i];
        if(zeros==5) options &= ~1;
        choices[i]=options;
        if(!options)return false;
        if(options&1)eligible++;
        if(options==1)forced++;
        if(countbits(options)<best) {slot=i;best=countbits(options);}
    }
    if(zeros+eligible<5 || zeros+forced>5)return false;
    todo^=1<<slot;
    for(int opt=choices[slot];opt;opt&=opt-1) {
        int c=first(opt);auto next=choices;
        if(c)for(int rem=todo;rem;rem&=rem-1){
            int j=first(rem);if(A[slot][j]==c)next[j]&=~(1<<c);
        }
        if(star(next,todo,zeros+(c==0)))return true;
    }
    return false;
}

using Board=array<array<int,15>,14>;
long long CSPnodes=0,entries=0;

// Enforce every cell of the 14 by 15 join. A fixed ordinary cell rules
// out that color on any same-color triangle with an old edge. The row and
// column tests enforce five zeros per outside vertex and the branch shapes.
bool complete(Board cells, Domains domains) {
    ++CSPnodes;
    bool changed=true;
    while(changed){
        changed=false;
        for(int x=0;x<14;x++) {
            int possible=0,forced=0;
            for(int a=0;a<15;a++){
                int mask=cells[x][a];
                if(!mask)return false;
                possible+=mask&1;forced+=mask==1;
                if(mask&(mask-1))continue;
                int c=first(mask);
                for(int y=0;y<14;y++)if(x!=y && edge[x][y]==c && (cells[y][a]&mask)){
                    cells[y][a]^=mask;changed=true;if(!cells[y][a])return false;
                }
                if(c)for(int b=0;b<15;b++)if(a!=b && A[a][b]==c && (cells[x][b]&mask)){
                    cells[x][b]^=mask;changed=true;if(!cells[x][b])return false;
                }
            }
            if(possible<5||forced>5)return false;
            if(possible==5||forced==5)for(int a=0;a<15;a++){
                int old=cells[x][a];
                if((old&1)&&old!=1)cells[x][a]=possible==5?1:old^1;
                changed|=old!=cells[x][a];
            }
        }
        int four=0,five=0;
        for(int a=0;a<15;a++){
            Mask options=domains[a];
            for(int x=0;x<14;x++){
                if(cells[x][a]==1)options&=contain[x];
                if(!(cells[x][a]&1))options&=~contain[x];
            }
            if(!options)return false;
            domains[a]=options;
            four+=!(options&s5);five+=!(options&s4);
            for(int x=0;x<14;x++){
                int old=cells[x][a];
                if(!(options&contain[x]))cells[x][a]&=~1;
                if(!(options&~contain[x]))cells[x][a]=1;
                changed|=old!=cells[x][a];
            }
        }
        if(four>5||five>10)return false;
        if(four==5||five==10)for(int a=0;a<15;a++){
            Mask old=domains[a];
            if((old&s4)&&(old&s5))domains[a]&=four==5?s5:s4;
            changed|=old!=domains[a];
        }
    }
    int bx=-1,ba=-1,sz=5;
    for(int x=0;x<14;x++)for(int a=0;a<15;a++){
        int n=countbits(cells[x][a]);if(n>1 && n<sz){sz=n;bx=x;ba=a;}
    }
    if (bx < 0) {
        if (enumerate_all) {
            model_file << catalogue_index << ' ' << palette_orientation << ' ';
            for (const auto &row : cells)
                for (int mask : row) model_file << first(mask);
            model_file << '\n';
        }
        return true;
    }
    bool found = false;
    int allowed=cells[bx][ba];
    for(int opt=allowed;opt;opt&=opt-1){
        cells[bx][ba]=opt&-opt;
        if (complete(cells,domains)) {
            if (!enumerate_all) return true;
            found = true;
        }
    }
    return found;
}

bool check_unassigned(const vector<int>& types,int used,const Domains& valid) {
    for(int rem=all^used;rem;rem&=rem-1) {
        int x=first(rem);
        array<int,15> choices;choices.fill(15);
        for(int a=0;a<15;a++){
            if(!(valid[a]&contain[x]))choices[a]&=~1;
            if(!(valid[a]&~contain[x]))choices[a]=1;
            for(int j=0;j<(int)types.size();j++){
                int c=edge[x][positions[j]];
                if(c==wordLetter[types[j]][a])choices[a]&=~(1<<c);
            }
        }
        if(!star(choices,(1<<15)-1,0))return false;
    }
    Board cells;for(auto&row:cells)row.fill(15);
    for(int j=0;j<(int)types.size();j++)for(int a=0;a<15;a++)cells[positions[j]][a]=1<<wordLetter[types[j]][a];
    entries++;
    return complete(cells,valid);
}

// Embed the chosen words in the 14 labelled slots of the catalogue arm.
// The state tracks possible slots for the remaining words and possible
// zero supports for each sender. Equal words may be put in name order.
bool assign_slots(const vector<int>& types, array<int,12> candidates, int left,
                  int used, const Domains& valid) {
    ++nodes;
    if(!left) {
        ++leaves;
        return check_unassigned(types,used,valid);
    }
    int choice=-1,minsize=15;
    for(int rem=left;rem;rem&=rem-1){
        int i=first(rem),n=countbits(candidates[i]);
        if(n==0)return false;
        if(n<minsize){choice=i;minsize=n;}
    }
    int w=types[choice];left^=1<<choice;
    bool found = false;
    for(int opt=candidates[choice];opt;opt&=opt-1){
        int slot=first(opt);
        array<int,12> next=candidates;
        bool ok=true;
        for(int rem=left;rem;rem&=rem-1){
            int j=first(rem);
            next[j]&=neighbors[slot][links[w][types[j]]];
            if(!next[j]){ok=false;break;}
        }
        if(!ok)continue;
        for(int j=0;j<(int)types.size();j++)if(j!=choice && !(left>>j&1) && types[j]==w){
            if((j<choice)!=(positions[j]<slot)){ok=false;break;}
        }
        if(!ok)continue;
        Domains after;int need4=0,need5=0;
        for(int a=0;a<15;a++) {
            after[a]=valid[a] & ((words[w][0]>>a&1)?contain[slot]:~contain[slot]);
            if(!after[a]){ok=false;break;}
            need4+=!(after[a]&s5);need5+=!(after[a]&s4);
        }
        if(!ok||need4>5||need5>10)continue;
        positions[choice]=slot;
        if (assign_slots(types,next,left,used|(1<<slot),after)) {
            if (!enumerate_all) return true;
            found = true;
        }
    }
    return found;
}

// Run with a list of candidate multisets, the arm color, multiset size, a
// half-open interval of catalogue rows, and the distinguished T template.
int main(int argc,char**argv){
    if (argc != 7 && argc != 8) return 2;
    if (argc == 8) {
        enumerate_all = true;
        model_file.open(argv[7]);
        if (!model_file) return 2;
    }
    string name=argv[1];int p=stoi(argv[2]),k=stoi(argv[3]);
    int lo=argc>4?stoi(argv[4]):0, hi=argc>5?stoi(argv[5]):332;
    ifstream patterns(name), graphs("graphs.txt"),tpl{argv[6]};
    int n,nc;tpl>>n>>nc;
    if (n != 15 || nc != 4 || !graphs || !patterns || !tpl || p != 1 || k < 2 || k > 7) return 2;
    for(auto&row:A)for(auto&c:row)tpl>>c;
    for(int i=0;i<18;i++){
        for(auto&m:words[i])patterns>>m;
        for(int a=0;a<15;a++)for(int f=0;f<4;f++)if(words[i][f]>>a&1)wordLetter[i][a]=f;
    }
    for(int i=0;i<18;i++)for(int j=0;j<18;j++)for(int f=0;f<4;f++)
        if(f!=p && !(words[i][f]&words[j][f]))links[i][j]|=1<<f;
    vector<vector<int>> types;int len;
    while(patterns>>len){vector<int>s(len);for(int&v:s)patterns>>v;if(len==k)types.push_back(s);}
    vector<int>other;for(int c=1;c<4;c++)if(c!=p)other.push_back(c);
    string g;long long survives=0,graphs_checked=0;
    vector<bool> seen(types.size(),false);
    for(int gi=0;graphs>>g;gi++){if(gi<lo||gi>=hi)continue;
      for(int swap=0;swap<2;swap++){
        catalogue_index = gi; palette_orientation = swap;
        for(auto&row:neighbors)fill(begin(row),end(row),0);
        int nedge=0;for(int i=0;i<14;i++)for(int j=i+1;j<14;j++){
          int e=g[nedge++]-'0';int c=e?other[(e-1)^swap]:0;edge[i][j]=edge[j][i]=c;
          for(int subset=0;subset<16;subset++)if(subset>>c&1){neighbors[i][subset]|=1<<j;neighbors[j][subset]|=1<<i;}
        }
        s4=s5=0;fill(begin(contain),end(contain),0);
        // Bit t denotes one allowed zero support in this arm. Four-point
        // supports induce two paths, and five-point supports induce two cycles.
        int cnt=0;
        for(int S=0;S<=all;S++){
          int size=countbits(S);if(size!=4&&size!=5)continue;
          int e[4]={};for(int high=S;high;high&=high-1){int i=first(high);for(int low=high&(high-1);low;low&=low-1)e[edge[i][first(low)]]++;}
          if(e[0] || (size==4 && e[other[0]]!=3))continue;
          if(cnt>=128)return 2;
          Mask bit=Mask(1)<<cnt++;(size==4?s4:s5)|=bit;
          for(int rem=S;rem;rem&=rem-1)contain[first(rem)]|=bit;
        }
        Domains all_supports;all_supports.fill(s4|s5);
        for(int pat=0;pat<(int)types.size();pat++){if(seen[pat] && !enumerate_all)continue;auto& s=types[pat];
          array<int,12>cand;cand.fill(all);
          if(assign_slots(s,cand,(1<<k)-1,0,all_supports)){
             ++survives;seen[pat]=true;
             if (!enumerate_all) {cout<<"example "<<k<<" graph "<<gi<<" swap "<<swap<<" types";for(int a:s)cout<<" "<<a;cout<<" slots";for(int j=0;j<k;j++)cout<<" "<<positions[j];cout<<endl;}
          }
        }
        ++graphs_checked;
      }
    }
    cout<<"CSP nodes "<<CSPnodes<<" entries "<<entries<<endl;cout<<"tested "<<graphs_checked<<" orientations, "<<types.size()<<" patterns, "<<nodes<<" nodes, "<<leaves<<" placements, "<<survives<<" feasible pattern-orientation pairs"<<endl;
}

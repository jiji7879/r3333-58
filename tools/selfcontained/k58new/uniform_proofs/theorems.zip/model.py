"""Local tables and incidence designs for two ordinary arms, normalized to colours 1 and 2."""
from collections import Counter
from functools import lru_cache
from itertools import combinations, permutations
from pathlib import Path
from data import HERE, catalogue, template
from capacity import supports

A = template()
U = [list(map(int, s.split())) for s in (HERE / 'U.col').read_text().splitlines()[1:]]
GRAPHS = catalogue()
EDGES = list(combinations(range(14), 2))
SHAPES = [(4, 5), (5, 4), (5, 5)]
SMALL = (2, 11, 13, 31, 39, 46)
EXPECTED = {2: 2, 11: 5, 13: 5, 31: 1, 39: 2, 46: 1,
            43: 42, 72: 42, 155: 42, 165: 42, 229: 42}

def pair(i, j):
    return (min(i, j), max(i, j))

def labelled_arm(type_id, arm, flip):
    palette = sorted({1, 2, 3} - {arm})
    if flip:
        palette.reverse()
    palette.insert(0, 0)
    return {e: palette[int(c)] for e, c in zip(EDGES, GRAPHS[type_id])}

def order(support, graph):
    adj = {v: [w for w in support if w != v and graph[pair(v, w)] == 3]
           for v in support}
    first = min(support, key=lambda v: (len(adj[v]), v))
    path = [first]
    while len(path) < len(support):
        path.append(min(v for v in adj[path[-1]] if v not in path))
    assert all((graph[pair(path[i], path[j])] == 3) == adjacent(len(path), i, j)
               for i, j in combinations(range(len(path)), 2))
    return path

def adjacent(n, i, j):
    return abs(j - i) == 1 or (n == 5 and abs(j - i) == 4)

@lru_cache(None)
def tables(m, n):
    out = set()
    for T in (A, U):
        for r in range(15):
            B = [v for v in range(15) if T[r][v] == 1]
            C = [v for v in range(15) if T[r][v] == 2]
            if (len(B), len(C)) != (m, n):
                continue
            def orders(S):
                return [p for p in permutations(S)
                        if all((T[p[i]][p[j]] == 3) == adjacent(len(S), i, j)
                               for i, j in combinations(range(len(S)), 2))]
            for p in orders(B):
                for q in orders(C):
                    out.add(tuple(T[b][c] for b in p for c in q))
    matches = Counter()
    for table in out:
        k = [(i, j) for i in range(m) for j in range(n) if table[n*i+j] == 3]
        assert len(k) == len({i for i,j in k}) == len({j for i,j in k}) == min(m,n)
        assert all(adjacent(m, b, u) != adjacent(n, c, v) for (b,c),(u,v) in combinations(k,2))
        matches[tuple(k)] += 1
    assert len(out) == 60 and sorted(matches.values()) == [6]*10
    return sorted(out)

def write_tail(f, H, K, L, R):
    print(*H.values(), file=f)
    print(*K.values(), file=f)
    for p, S in enumerate(L):
        for q, T in enumerate(R):
            if (len(S), len(T)) not in SHAPES:
                continue
            b, c = order(S, H), order(T, K)
            print(p,q,len(b),*b,len(c),*c,file=f)
    print(-1,file=f)
    for m, n in SHAPES:
        ts = tables(m,n)
        print(m,n,len(ts),file=f)
        for t in ts:
            print(''.join(map(str,t)),file=f)

def multisets_for(idx, vectors):
    cols = supports(GRAPHS[idx])
    return [[s for s,k in zip(cols,v) for _ in range(k)] for v in vectors[idx]]
